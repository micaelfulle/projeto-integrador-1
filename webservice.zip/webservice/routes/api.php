<?php

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Produto;
use Illuminate\Validation\Rule;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::post('/cadastro', function (Request $request) {
    $data = $request->all();

    $validacao = Validator::make($data, [
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255|unique:users',
        'password' => 'required|string|min:6|confirmed',
    ]);
  
    if($validacao->fails()){
      return $validacao->errors();
    }

    $user = User::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'password' => bcrypt($data['password']),
    ]);

    $user->token = $user->createToken($user->email)->accessToken;

    return $user;
});

//login
Route::post('/login', function (Request $request) {

    $validacao = Validator::make($request->all(), [
        'email' => 'required|string|email|max:255',
        'password' => 'required|string',
    ]);

    if($validacao->fails()){
      return $validacao->errors();
    }

    if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
        // Authentication passed...
        $user = Auth()->user();
        $user->token = $user->createToken($user->email)->accessToken;
        return $user;
    }else{
      return ['status'=>"erro no login"];
    }
});

Route::middleware('auth:api')->get('/usuarios', function (Request $request) {
    return User::all();
});

Route::middleware('auth:api')->get('/usuario', function (Request $request) {
    $user = $request->user();
    $user->token = $user->createToken($user->email)->accessToken;
    return $user;
});

//atualização de perfil
Route::middleware('auth:api')->put('/usuario', function (Request $request) {
    $user = $request->user();
    $data = $request->all();

    if(isset($data['password']) && $data['password'] != ""){
        $validacao = Validator::make($data, [
            'name' => 'required|string|max:255',
            'email' => ['required','string','email','max:255',Rule::unique('users')->ignore($user->id)],
            'password' => 'required|string|min:6',
        ]);
        if($validacao->fails()){
            return $validacao->errors();
          }
        $data['password'] = bcrypt($data['password']);

      }elseif(isset($data['password']) && $data['password'] == ""){

          unset($data['password']);

          $validacao = Validator::make($data, [
            'name' => 'required|string|max:255',
            'email' => ['required','string','email','max:255',Rule::unique('users')->ignore($user->id)]
        
        ]);
        if($validacao->fails()){
            return $validacao->errors();
          }
      }else{
          $validacao = Validator::make($data, [
        'name' => 'required|string|max:255',
        'email' => ['required','string','email','max:255',Rule::unique('users')->ignore($user->id)]
        ]);
        if($validacao->fails()){
            return $validacao->errors();
        }
    }
    $user->update($data);
    $user->token = $user->createToken($user->email)->accessToken;
    return $user;

});

//criação de produtos
Route::get('/admin/criar/produtos', function (Request $request) {
    $produto = Produto:: create(
        [
     "nome"=>"Leite Tirol",
     "descricao"=>"1lt",
     "valor"=>2.10,
     "valor_txt"=>" 2,10",
     "imagem"=>"https://img2.sitemercado.com.br/produtos/e0e8709fa81d6e6605ae98ec5ecc7fe23e8b54e134a9dcb0119edfb562bab417_full.jpg"
        ]
        );
        return $produto;
       /* $categoria = Produto::find(2)->categorias()->create([
            "nome"=> "Bebidas"
        ]);
         
            return $categoria;*/
});
//lista de produtos
Route::get('/produtos', function (Request $request) {
    $produtos = Produto::all();
    return $produtos; 
});  
//compras
Route::middleware('auth:api')->post('/compra', function (Request $request) {
    $user = $request->user();
    $data = $request->all();
    $lista_produtos_id = explode(",", $data['produtos']);
   
    $produtos = [];
    $total=0;
    foreach($lista_produtos_id as $key=>$value){
        $produto = Produto::find($value);
        if($produto){
            $produtos[$key] = $produto;
            $total += $produto->valor;
        }
    }
    if($total){
        $compra = $user->compras()->create(
            [
                'data'=>date('Y-m-d'),
                'total'=>$total,
                'status'=>'aguardando'
            ]
        );
        foreach($produtos as $key =>$value){
            $compra->produtos()->create(
                [
                'user_id'=>$user->id,
                'nome'=> $value->nome,
                'valor'=>$value->valor
                ]
                );
        }

        return $compra;
    }
    
    return ['status'=>'erro na compra'];
    
});
//listar a compra
Route::middleware('auth:api')->get('/compra', function (Request $request) {
    $user = $request->user();
    return $user->compras()->with('produtos')->get();
    
});