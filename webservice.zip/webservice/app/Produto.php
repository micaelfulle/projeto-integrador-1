<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;
class Produto extends Model
{
    protected $fillable= [
        'user_id',
        'nome',
        'descricao',
        'valor',
        'valor_txt',
        'imagem'
    ];

    public function categoria(){
        return $this->belongsTo('App\Categoria');
    }

    public function compra(){
        return $this->belongsTo('App\Compra');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }
}
