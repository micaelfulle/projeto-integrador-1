<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;
class Categoria extends Model
{
    protected $fillable= [
        'nome'
    ];

    public function produtos(){
        return $this->hasMany('App\Produto');
    }
}
