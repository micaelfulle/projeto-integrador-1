<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;


class Compra extends Model
{
    protected $fillable=[
        'data',
        'total',
        'status'
    ];

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function produtos(){
        return $this->hasMany('App\Produto');
    }
}
